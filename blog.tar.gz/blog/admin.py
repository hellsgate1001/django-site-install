from [~projectname~].blog.models import *
from django.contrib import admin
from [~projectname~].blog.forms import BlogWithImageAdminForm


class BlogWithImageAdmin(admin.ModelAdmin):
    form = BlogWithImageAdminForm
    prepopulated_fields = {
        'slug': ('title',)
    }


admin.site.register(BlogWithImage, BlogWithImageAdmin)
admin.site.register(Category)
