from django.db import models
from basic.blog.models import Post, Category
from [~projectname~].lib.thumbs import ImageWithThumbsField
from django.forms import ModelForm


try:
    from south.modelsinspector import add_introspection_rules
    add_introspection_rules([], ['^tagging\.fields\.TagField'])
except ImportError:
    pass


class BlogWithImage(Post):
    image = ImageWithThumbsField(
        upload_to='uploads/images/blog/',
        max_length=256,
        sizes=((385, 258), (307, 206), (248, 166), (223, 150)),
        help_text='Large image required. Images will be scaled to 307x206',
        verbose_name='Large Image'
    )

    def __unicode__(self):
        return self.title

    class Meta:
        verbose_name = 'Post'
        verbose_name_plural = 'Posts'


class Category(Category):
    def __unicode__(self):
        return self.title
