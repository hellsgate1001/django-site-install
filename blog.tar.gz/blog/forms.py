from django.forms.models import ModelForm
from django import forms
from [~projectname~].blog.models import BlogWithImage
from tinymce.widgets import TinyMCE


class BlogWithImageAdminForm(ModelForm):
    body = forms.CharField(
        widget=TinyMCE(
            attrs={'cols': 40, 'rows': 30},
        )
    )
    class Meta:
        model = BlogWithImage
