from django import template
from begg.lib.summarize import SimpleSummarizer

register = template.Library()


def get_summary(value, num_sentences):
    summary = SimpleSummarizer().summarize(value, int(num_sentences))
    if len(summary) < len(value):
        return summary
    else:
        return value[:160] + '...'

register.filter('get_summary', get_summary)

""" from django import template

register = template.Library()

def get_summary(value, length = 9):
    return value[:length]


register.filter('substr', substr) """
    
